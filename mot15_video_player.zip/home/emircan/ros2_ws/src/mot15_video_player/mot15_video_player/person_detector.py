import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np

class KalmanPersonTracker:
    def __init__(self):
        self.kalman = cv2.KalmanFilter(4, 2)
        self.kalman.measurementMatrix = np.array([[1, 0, 0, 0], [0, 1, 0, 0]], np.float32)
        self.kalman.transitionMatrix = np.array([[1, 0, 1, 0], [0, 1, 0, 1], [0, 0, 1, 0], [0, 0, 0, 1]], np.float32)
        self.kalman.processNoiseCov = np.eye(4, dtype=np.float32) * 0.03

    def update(self, position):
        if position is not None:
            x, y, w, h = position
            measurement = np.array([[np.float32(x + w / 2)], [np.float32(y + h / 2)]])
            self.kalman.correct(measurement)
        predicted = self.kalman.predict()
        return int(predicted[0]), int(predicted[1])

class ImageSubscriber(Node):
    def __init__(self):
        super().__init__('person_detector')
        self.subscription = self.create_subscription(
            Image, 'image_topic', self.listener_callback, 10)
        self.bridge = CvBridge()
        self.haar_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_fullbody.xml')
        self.prev_gray = None  # Optik akış için önceki kare
        self.lk_params = dict(winSize=(15, 15), maxLevel=2, criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 10, 0.03))
        self.tracker = KalmanPersonTracker()
        self.person_count = 0
        self.tracked_positions = []

    def listener_callback(self, msg):
        frame = self.bridge.imgmsg_to_cv2(msg, 'bgr8')
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        if self.prev_gray is None:
            self.prev_gray = gray
            return

        # Optik akış hesapla
        flow = cv2.calcOpticalFlowFarneback(self.prev_gray, gray, None, 0.5, 3, 15, 3, 5, 1.2, 0)

        # Akış vektörlerinin büyüklüğünü hesapla
        mag, ang = cv2.cartToPolar(flow[..., 0], flow[..., 1])

        # Sadece belirli bir akışın üzerindeki pikselleri seç
        moving_mask = mag > 2.0  # Eşik değer, ayarlanabilir

        # Hareketli pikselleri işaretle
        moving_mask = moving_mask.astype(np.uint8) * 255
        contours, _ = cv2.findContours(moving_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        detected_positions = []
        for (x, y, w, h) in self.haar_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=2, minSize=(35, 35)):
            for contour in contours:
                if cv2.contourArea(contour) < 500:  # Küçük gürültüleri engelle
                    continue
                (cx, cy, cw, ch) = cv2.boundingRect(contour)
                if self._is_inside((x, y, w, h), (cx, cy, cw, ch)):
                    center = (x + w // 2, y + h // 2)
                    detected_positions.append(center)
                    predicted_position = self.tracker.update((x, y, w, h))

                    if not any(np.linalg.norm(np.array(center) - np.array(pos)) < 50 for pos in self.tracked_positions):
                        self.tracked_positions.append(center)
                        self.person_count += 1

                    cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        cv2.putText(frame, f'Toplam Kisi: {self.person_count}', (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2, cv2.LINE_AA)

        cv2.imshow('Hareketli Kamera Kisi Tespiti', frame)
        cv2.waitKey(1)

        self.prev_gray = gray  # Mevcut kareyi önceki kare olarak sakla

    def _is_inside(self, person_rect, contour_rect):
        px, py, pw, ph = person_rect
        cx, cy, cw, ch = contour_rect
        return px >= cx and py >= cy and px + pw <= cx + cw and py + ph <= cy + ch

def main(args=None):
    rclpy.init(args=args)
    image_subscriber = ImageSubscriber()
    try:
        rclpy.spin(image_subscriber)
    except KeyboardInterrupt:
        pass
    finally:
        image_subscriber.destroy_node()
        rclpy.shutdown()
        cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
