# mot15_video_player/__init__.py

# Bu dosya, mot15_video_player paketini tanımlamak için gereklidir.
