import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import os

class MOT15ImagePublisher(Node):
    def __init__(self, image_folder):
        super().__init__('image_publisher')
        self.publisher_ = self.create_publisher(Image, 'image_topic', 10)
        self.timer = self.create_timer(0.1, self.publish_image)  # 10 FPS
        self.bridge = CvBridge()
        self.image_folder = image_folder
        self.image_files = sorted(os.listdir(image_folder))
        self.current_index = 0

    def publish_image(self):
        if self.current_index < len(self.image_files):
            img_path = os.path.join(self.image_folder, self.image_files[self.current_index])
            frame = cv2.imread(img_path)
            if frame is not None:
                msg = self.bridge.cv2_to_imgmsg(frame, encoding='bgr8')
                self.publisher_.publish(msg)
                self.get_logger().info(f'Published {img_path}')
            self.current_index += 1
        else:
            self.get_logger().info('All images published.')
            self.destroy_timer(self.timer)

def main(args=None):
    rclpy.init(args=args)
    image_folder = '/home/emircan/ros2_ws/src/mot15_video_player/MOT15/test/ETH-Linthescher/img1' # Resimlerin bulunduğu klasörün yolu
    node = MOT15ImagePublisher(image_folder)
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
