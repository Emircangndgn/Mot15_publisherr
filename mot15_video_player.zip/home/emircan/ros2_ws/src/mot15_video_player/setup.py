from setuptools import setup, find_packages

package_name = 'mot15_video_player'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(),
    install_requires=['setuptools', 'opencv-python', 'cv_bridge'],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    entry_points={
        'console_scripts': [
            'image_publisher = mot15_video_player.image_publisher:main',
            'image_subscriber = mot15_video_player.image_subscriber:main',
            'person_detector = mot15_video_player.person_detector:main',
        ],
    },
)
